# -*- coding: utf-8 -*-

__name__ = 'NodeEditor'
__author__ = 'Pavel Křupala'
__version__ = '0.9.13'
