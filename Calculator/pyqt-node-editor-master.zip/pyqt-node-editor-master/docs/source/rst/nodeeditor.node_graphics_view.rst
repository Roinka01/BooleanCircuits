.. py:currentmodule:: nodeeditor.node_graphics_view

:py:mod:`node\_graphics\_view` Module
======================================

.. automodule:: nodeeditor.node_graphics_view
    :members: MODE_NOOP, MODE_EDGE_DRAG, MODE_EDGE_CUT, MODE_EDGES_REROUTING, EDGE_DRAG_START_THRESHOLD

    Constants
    ---------


`QDMGraphicsView` class
-----------------------

.. autoclass:: QDMGraphicsView
    :members:
    :undoc-members:
    :show-inheritance:
