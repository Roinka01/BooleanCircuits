.. py:currentmodule:: nodeeditor.node_edgitor_window

:py:mod:`node\_editor\_window` Module
======================================

.. automodule:: nodeeditor.node_editor_window
    :members:
    :undoc-members:
    :show-inheritance:
