.. py:currentmodule:: nodeeditor.node_graphics_socket

:py:mod:`node\_graphics\_socket` Module
========================================

.. automodule:: nodeeditor.node_graphics_socket
    :members:
    :undoc-members:
    :show-inheritance:
